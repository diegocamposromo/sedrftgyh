# PROC45-1_4-plantilla-proyecto
Atrapa frutas. Etapa 2. Botón de reinicio.  

Modificación por parte del alumno en dos secciones diferentes.  

Firebase activo.  

## Nombre en Inglés: project-template-FRUIT-CATCHER---II
